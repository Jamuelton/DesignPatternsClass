package br.upe.ppsw.jabberpoint;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JabberPointApplicationTests {

  public JabberPointApplicationTests() {

  }

  @Test
  public void contextLoads() {}

}
